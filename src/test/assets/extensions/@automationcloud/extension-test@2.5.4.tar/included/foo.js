export class FooAction {
    // Note: this doesn't actually implement anything;
    // tests use this for ensuring the correct integrity of bundle
}
